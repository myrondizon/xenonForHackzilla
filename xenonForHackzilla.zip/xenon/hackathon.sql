-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 01, 2017 at 09:34 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hackathon`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `chat_id` int(30) NOT NULL,
  `chat_user` varchar(50) NOT NULL,
  `chat_message` varchar(150) NOT NULL,
  `chat_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `chat_type` enum('text','image') NOT NULL,
  `chat_second_person` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`chat_id`, `chat_user`, `chat_message`, `chat_time`, `chat_type`, `chat_second_person`) VALUES
(645, 'jhoebe', 'Hi, Xenon! Can you suggest an outfit for me?', '2017-04-01 06:33:48', 'text', ''),
(646, 'xenon', 'Sure. What style do you want me to suggest?', '2017-04-01 06:33:48', 'text', 'jhoebe'),
(647, 'jhoebe', 'Please suggest a casual outfit', '2017-04-01 06:34:03', 'text', ''),
(648, 'xenon', 'Here are some suggestions with casual attire.', '2017-04-01 06:34:03', 'text', 'jhoebe'),
(650, 'jhoebe', 'Yes, I did like it! Thank you.', '2017-04-01 06:34:55', 'text', ''),
(651, 'xenon', 'Glad you liked it!', '2017-04-01 06:34:55', 'text', 'jhoebe'),
(664, 'jhoebe', 'Hi, Xenon. Are there any available promos for sperry?', '2017-04-01 07:33:06', 'text', ''),
(665, 'xenon', 'There are promotions for sperry! The nearest to you is in Trinoma.', '2017-04-01 07:33:06', 'text', 'jhoebe');

-- --------------------------------------------------------

--
-- Table structure for table `promos`
--

CREATE TABLE `promos` (
  `promo_id` int(11) NOT NULL,
  `promo_mall` varchar(40) NOT NULL,
  `promo_brand` varchar(40) NOT NULL,
  `promo_description` varchar(40) NOT NULL,
  `promo_date` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `promos`
--

INSERT INTO `promos` (`promo_id`, `promo_mall`, `promo_brand`, `promo_description`, `promo_date`) VALUES
(1, 'Trinoma', 'Sperry', '50% off on selected products', 'April 5, 2017'),
(2, 'SM Malls Nationwide', 'Forever 21', 'Buy 2, Take 1 free!', 'April 9, 2017'),
(3, 'SM San Lazaro', 'Sperry', '50% off on selected items!', 'April 5, 2017');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(20) NOT NULL,
  `user_name` char(20) NOT NULL,
  `user_email` varchar(40) NOT NULL,
  `user_password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_email`, `user_password`) VALUES
(1, 'jhoebe', 'jhoebe@yahoo.com', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `words`
--

CREATE TABLE `words` (
  `word_id` int(11) NOT NULL,
  `word` varchar(30) NOT NULL,
  `word_action` enum('find','suggest','yes','no','type','specific','promo') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `words`
--

INSERT INTO `words` (`word_id`, `word`, `word_action`) VALUES
(24, 'find', 'find'),
(25, 'suggest', 'suggest'),
(26, 'recommend', 'suggest'),
(27, 'yes', 'yes'),
(28, 'no', 'no'),
(29, 'outfit', 'type'),
(30, 'attire', 'type'),
(31, 'color', 'type'),
(32, 'business', 'specific'),
(33, 'casual', 'specific'),
(34, 'formal', 'specific'),
(35, 'promo', 'promo'),
(36, 'discounts', 'promo'),
(37, 'discount', 'promo'),
(38, 'sale', 'promo'),
(39, 'promos', 'promo'),
(40, 'promotions', 'promo'),
(41, 'liked', 'yes'),
(42, 'loved', 'yes'),
(43, 'like', 'yes'),
(44, 'no', 'no'),
(45, 'did not', 'no'),
(46, 'didnt like', 'no'),
(47, 'did not like', 'no'),
(48, 'unattractive', 'no');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`chat_id`);

--
-- Indexes for table `promos`
--
ALTER TABLE `promos`
  ADD PRIMARY KEY (`promo_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `words`
--
ALTER TABLE `words`
  ADD PRIMARY KEY (`word_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `chat_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=666;
--
-- AUTO_INCREMENT for table `promos`
--
ALTER TABLE `promos`
  MODIFY `promo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `words`
--
ALTER TABLE `words`
  MODIFY `word_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
