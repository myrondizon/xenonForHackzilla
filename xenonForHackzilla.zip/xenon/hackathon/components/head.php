<meta name="viewport" content="width=device-width">
<link type="text/css" rel="stylesheet" href="tools/semantic/semantic.css">
        <link type="text/css" rel="stylesheet" href="components/css/main.css">
        <script type="text/javascript" src="components/js/jquery.js"></script>
        <script type="text/javascript" src="components/js/main.js"></script>
        <script type="text/javascript" src="tools/semantic/semantic.js"></script>