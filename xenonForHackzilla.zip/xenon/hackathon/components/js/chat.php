<?php 
	$q1= $_POST['q1'];
    echo $q1;
?>