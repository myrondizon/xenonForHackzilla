$(document).ready(function(){
        $("#chatbot_send").click(function(){
            
            $('#chat_logs').stop().animate({
                scrollTop: $('#chat_logs')[0].scrollHeight
              }, 300);

            
            var chatbot_field = document.getElementById("chatbot_field").value;
            
            $.ajax({
                method: 'POST',
                url: 'back_end/chat.php',
                data: {"ajax_chatbot_field": chatbot_field},
                
                
                success: function(html) {
                    
                    if(html === "fail"){
                        alert("no message was typed");
                    }else{
                        $("#chat_logs").load("sep.php");
                    }
                }
            });
            
        return false;
   });
});

$(document).ready(function () {
    setInterval(function() {
        $.get("sep.php", function (result) {
            $('#chat_logs').html(result);
        });
    }, 5000);
});

